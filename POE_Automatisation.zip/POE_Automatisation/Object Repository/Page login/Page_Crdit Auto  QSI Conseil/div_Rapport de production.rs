<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Rapport de production</name>
   <tag></tag>
   <elementGuidId>1e551a04-ef15-4045-a15c-209dc2264ca2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='page-top']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.jumbotron.bg-transparent</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e99e2253-a16b-4013-9043-d37a9524e41f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>jumbotron bg-transparent</value>
      <webElementGuid>99a6f3df-507c-41f2-800e-536880800630</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        Rapport de production
    </value>
      <webElementGuid>d06d1290-c40d-4a9e-beac-f13793d5a041</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-top&quot;)/div[@class=&quot;jumbotron bg-transparent&quot;]</value>
      <webElementGuid>586b6b98-00da-47a1-a16f-5e2b966f27fa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='page-top']/div</value>
      <webElementGuid>2fbe93bf-d688-4ff3-bfa2-4405135e68a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Déconnexion'])[1]/following::div[1]</value>
      <webElementGuid>47515bac-863c-4c94-aa75-4902f11f8fd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='acd'])[1]/following::div[2]</value>
      <webElementGuid>15c3277c-544d-468a-ac33-3850718d2469</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('La date doit être inférieure à la date d', &quot;'&quot;, 'aujourd', &quot;'&quot;, 'hui !')])[1]/preceding::div[5]</value>
      <webElementGuid>539b0736-eddf-44b5-ba5c-65d01677f3b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body/div</value>
      <webElementGuid>6a7e9e0a-6f75-4929-8e7d-ccd785bfc4da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        Rapport de production
    ' or . = '
        Rapport de production
    ')]</value>
      <webElementGuid>9b6bfd9b-3e52-42b4-8d5d-7ca06e85f6c7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
