<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Se connecter</name>
   <tag></tag>
   <elementGuidId>47dfa0c7-c64e-4416-94a8-d6cb325036f3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@type='submit']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.btn.btn-dark</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>53764c4b-167e-4b18-90e1-27a2fb40e39f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>submit</value>
      <webElementGuid>a4f3619d-d9c1-431d-8d93-55fcb8fe6296</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-dark</value>
      <webElementGuid>312a39bc-da0e-444e-a5f7-d6c04204a7f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                             Se connecter
                        </value>
      <webElementGuid>a7834769-b79d-4280-a92b-bd6f76ab49a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-top&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;offset-lg-3 offset-md-3 offset-sm-3 col-sm-6&quot;]/div[@class=&quot;jumbotron&quot;]/form[1]/fieldset[1]/button[@class=&quot;btn btn-dark&quot;]</value>
      <webElementGuid>6d2b47d3-d296-4cfd-bd0c-879f3d9bd3f9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@type='submit']</value>
      <webElementGuid>a010da84-4904-4d27-90cd-70c4c5217283</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='page-top']/div[2]/div/div/form/fieldset/button</value>
      <webElementGuid>d00fbf29-549d-4689-98d2-c2debff2e0ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mot de passe'])[1]/following::button[1]</value>
      <webElementGuid>15cd874b-a5c8-4fa7-a5d7-24b325f5dde0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Nom d', &quot;'&quot;, 'utilisateur')])[1]/following::button[1]</value>
      <webElementGuid>668b824c-b4a7-4e39-aa3b-7f5e7a58e881</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Copyright © QSI Conseil 2022'])[1]/preceding::button[1]</value>
      <webElementGuid>873bd04a-6993-4be4-b2c0-e1284cdbdfff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capture object:'])[1]/preceding::button[1]</value>
      <webElementGuid>b3799952-7cfa-4ae1-b24a-1ea4db0bb7fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Se connecter']/parent::*</value>
      <webElementGuid>89f15a37-bb76-40e0-8a75-9eff7a07e745</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//fieldset/button</value>
      <webElementGuid>b3cfd87b-19b4-4f47-8fa9-1816cbc25743</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'submit' and (text() = '
                             Se connecter
                        ' or . = '
                             Se connecter
                        ')]</value>
      <webElementGuid>3bb67df3-5d6e-48df-961a-e6f0daa7d3fd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
