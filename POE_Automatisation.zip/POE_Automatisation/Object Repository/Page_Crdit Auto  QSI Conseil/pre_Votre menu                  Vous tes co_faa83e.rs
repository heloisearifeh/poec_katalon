<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>pre_Votre menu                  Vous tes co_faa83e</name>
   <tag></tag>
   <elementGuidId>e60c2364-f2c7-4fe2-86ff-7dc55201837b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>pre</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='page-top']/div[2]/div/pre</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>pre</value>
      <webElementGuid>dd6c6836-1bd4-41e0-8e46-b38e0bfc69e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>                Votre menu : 
                Vous êtes connecté en tant que : acd
                Vous êtes : L'Administrateur de Crédit Auto
                Voici la liste de vos fonctionnalités :
                 - Vérifier l'admissibilté d'un client pour établir un contrat de crédit automobile : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Effectuer une simulation : Cliquez ici
                 - Rechercher les contrats en cours : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Consulter le rapport de production : Cliquez ici
                 - Emettre vos conditions de location : Cliquez ici
                 - Définir le taux d'intérêt : Cliquez ici
                 - Consulter la liste des conditions des loueurs partenaires : Cliquez ici
                 - Consulter la liste des loueurs partenaires : Cliquez ici
            </value>
      <webElementGuid>407b49ba-4e8f-4e4a-9f15-278fbcea1e9c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-top&quot;)/div[@class=&quot;row col-12 ml-auto&quot;]/div[@class=&quot;offset-3 col-9&quot;]/pre[1]</value>
      <webElementGuid>1165df5f-d16c-4d9c-ab33-e8887fc47af6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='page-top']/div[2]/div/pre</value>
      <webElementGuid>d2148eea-d3c0-4257-a373-c28081c8b87a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Bienvenue sur l', &quot;'&quot;, 'application Crédit Auto')])[1]/following::pre[1]</value>
      <webElementGuid>2172e9a3-7892-4481-bb9b-beefe80f9a08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Déconnexion'])[1]/following::pre[1]</value>
      <webElementGuid>42eeb389-d7a5-4376-9129-3493ccf39bb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Vous êtes connecté en tant que :']/parent::*</value>
      <webElementGuid>b891e04e-0b82-4a79-8284-0c35c7e678bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//pre</value>
      <webElementGuid>fbcbf737-9af4-45da-ab86-607799ee3bbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//pre[(text() = concat(&quot;                Votre menu : 
                Vous êtes connecté en tant que : acd
                Vous êtes : L&quot; , &quot;'&quot; , &quot;Administrateur de Crédit Auto
                Voici la liste de vos fonctionnalités :
                 - Vérifier l&quot; , &quot;'&quot; , &quot;admissibilté d&quot; , &quot;'&quot; , &quot;un client pour établir un contrat de crédit automobile : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Effectuer une simulation : Cliquez ici
                 - Rechercher les contrats en cours : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Consulter le rapport de production : Cliquez ici
                 - Emettre vos conditions de location : Cliquez ici
                 - Définir le taux d&quot; , &quot;'&quot; , &quot;intérêt : Cliquez ici
                 - Consulter la liste des conditions des loueurs partenaires : Cliquez ici
                 - Consulter la liste des loueurs partenaires : Cliquez ici
            &quot;) or . = concat(&quot;                Votre menu : 
                Vous êtes connecté en tant que : acd
                Vous êtes : L&quot; , &quot;'&quot; , &quot;Administrateur de Crédit Auto
                Voici la liste de vos fonctionnalités :
                 - Vérifier l&quot; , &quot;'&quot; , &quot;admissibilté d&quot; , &quot;'&quot; , &quot;un client pour établir un contrat de crédit automobile : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Effectuer une simulation : Cliquez ici
                 - Rechercher les contrats en cours : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Consulter le rapport de production : Cliquez ici
                 - Emettre vos conditions de location : Cliquez ici
                 - Définir le taux d&quot; , &quot;'&quot; , &quot;intérêt : Cliquez ici
                 - Consulter la liste des conditions des loueurs partenaires : Cliquez ici
                 - Consulter la liste des loueurs partenaires : Cliquez ici
            &quot;))]</value>
      <webElementGuid>6f9d275d-dbd4-4cf1-86d4-bb7e196033d2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
