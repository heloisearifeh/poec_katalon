<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Votre menu                  Vous tes co_1aa3c7</name>
   <tag></tag>
   <elementGuidId>053a9c93-ca9a-46e9-8d8a-a9c92201a6b2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.offset-3.col-9</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='page-top']/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3d8521e4-4059-4288-b522-4fd2db7c8c32</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>offset-3 col-9</value>
      <webElementGuid>bd9006b5-b711-4b11-aec3-240a6b9d483a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                            Votre menu : 
                Vous êtes connecté en tant que : acd
                Vous êtes : L'Administrateur de Crédit Auto
                Voici la liste de vos fonctionnalités :
                 - Vérifier l'admissibilté d'un client pour établir un contrat de crédit automobile : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Effectuer une simulation : Cliquez ici
                 - Rechercher les contrats en cours : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Consulter le rapport de production : Cliquez ici
                 - Emettre vos conditions de location : Cliquez ici
                 - Définir le taux d'intérêt : Cliquez ici
                 - Consulter la liste des conditions des loueurs partenaires : Cliquez ici
                 - Consulter la liste des loueurs partenaires : Cliquez ici
            

        </value>
      <webElementGuid>a833ffee-b968-4999-a61f-ae8d663e0b05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-top&quot;)/div[@class=&quot;row col-12 ml-auto&quot;]/div[@class=&quot;offset-3 col-9&quot;]</value>
      <webElementGuid>f7f145b7-9c47-4f4e-8235-c2a915ceacaa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='page-top']/div[2]/div</value>
      <webElementGuid>a4a994a1-8eaa-4b2f-87a9-b9d705233da1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Bienvenue sur l', &quot;'&quot;, 'application Crédit Auto')])[1]/following::div[2]</value>
      <webElementGuid>655509f7-1938-48d5-bd10-e1e60c899312</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Déconnexion'])[1]/following::div[3]</value>
      <webElementGuid>ad37ccc8-b8ff-4935-b00b-b7d3eabc1b17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div</value>
      <webElementGuid>0898ddcd-24c1-43c1-a365-2a8d1f0f6259</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;

                            Votre menu : 
                Vous êtes connecté en tant que : acd
                Vous êtes : L&quot; , &quot;'&quot; , &quot;Administrateur de Crédit Auto
                Voici la liste de vos fonctionnalités :
                 - Vérifier l&quot; , &quot;'&quot; , &quot;admissibilté d&quot; , &quot;'&quot; , &quot;un client pour établir un contrat de crédit automobile : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Effectuer une simulation : Cliquez ici
                 - Rechercher les contrats en cours : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Consulter le rapport de production : Cliquez ici
                 - Emettre vos conditions de location : Cliquez ici
                 - Définir le taux d&quot; , &quot;'&quot; , &quot;intérêt : Cliquez ici
                 - Consulter la liste des conditions des loueurs partenaires : Cliquez ici
                 - Consulter la liste des loueurs partenaires : Cliquez ici
            

        &quot;) or . = concat(&quot;

                            Votre menu : 
                Vous êtes connecté en tant que : acd
                Vous êtes : L&quot; , &quot;'&quot; , &quot;Administrateur de Crédit Auto
                Voici la liste de vos fonctionnalités :
                 - Vérifier l&quot; , &quot;'&quot; , &quot;admissibilté d&quot; , &quot;'&quot; , &quot;un client pour établir un contrat de crédit automobile : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Effectuer une simulation : Cliquez ici
                 - Rechercher les contrats en cours : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Consulter le rapport de production : Cliquez ici
                 - Emettre vos conditions de location : Cliquez ici
                 - Définir le taux d&quot; , &quot;'&quot; , &quot;intérêt : Cliquez ici
                 - Consulter la liste des conditions des loueurs partenaires : Cliquez ici
                 - Consulter la liste des loueurs partenaires : Cliquez ici
            

        &quot;))]</value>
      <webElementGuid>8a7bae27-8325-4626-9299-4679c67f44cf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
