<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>fieldset_Connectez-vous                    _95c4f0</name>
   <tag></tag>
   <elementGuidId>cd87c4e4-fe46-42da-8d67-6e83b412010d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='page-top']/div[2]/div/div/form/fieldset</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>fieldset</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>fieldset</value>
      <webElementGuid>f003c453-42f0-41f1-8359-d72c9fdcf80f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                         Connectez-vous
                        
                            Nom d'utilisateur
                            
                        
                        
                            Mot de passe
                            
                        
                        
                        
                        
                             Se connecter
                        
                    </value>
      <webElementGuid>894a40df-9a15-47b8-9314-a40cd9141386</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-top&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;offset-lg-3 offset-md-3 offset-sm-3 col-sm-6&quot;]/div[@class=&quot;jumbotron&quot;]/form[1]/fieldset[1]</value>
      <webElementGuid>5df24218-c694-4e90-bdf3-dc7538ac131b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='page-top']/div[2]/div/div/form/fieldset</value>
      <webElementGuid>5ff79439-1846-4b52-85a5-8ecbe9a9d7f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accueil'])[1]/following::fieldset[1]</value>
      <webElementGuid>7de16add-1736-4caa-888c-008bee9d4ccb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Crédit Auto'])[1]/following::fieldset[1]</value>
      <webElementGuid>b4c879cd-c231-4344-8bd9-b5f11049cca2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//fieldset</value>
      <webElementGuid>4cd0d338-38a5-4317-8d7a-8e66f0c0e1d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//fieldset[(text() = concat(&quot;
                         Connectez-vous
                        
                            Nom d&quot; , &quot;'&quot; , &quot;utilisateur
                            
                        
                        
                            Mot de passe
                            
                        
                        
                        
                        
                             Se connecter
                        
                    &quot;) or . = concat(&quot;
                         Connectez-vous
                        
                            Nom d&quot; , &quot;'&quot; , &quot;utilisateur
                            
                        
                        
                            Mot de passe
                            
                        
                        
                        
                        
                             Se connecter
                        
                    &quot;))]</value>
      <webElementGuid>801632b0-ac34-4c7b-ab04-987dd9c2fddf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
