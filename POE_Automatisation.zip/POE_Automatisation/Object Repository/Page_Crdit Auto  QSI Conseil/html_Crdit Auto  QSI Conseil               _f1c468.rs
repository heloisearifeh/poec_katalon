<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>html_Crdit Auto  QSI Conseil               _f1c468</name>
   <tag></tag>
   <elementGuidId>09a2600a-730d-4977-9eb0-e15dacd347ba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>html</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='']/parent::*</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>html</value>
      <webElementGuid>b570d3fd-4a33-46ee-8e58-ceb140f7dc67</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        Crédit Auto | QSI Conseil
                
        
        
        
        
        
        
        
                
            /* Sticky footer styles
-------------------------------------------------- */
            html {
                position: relative;
                min-height: 100%;
            }
            body {
                /* Margin bottom by footer height */
                margin-bottom: 60px;
            }
            .footer {
                position: absolute;
                bottom: 0;
                width: 100%;
                /* Set the fixed height of the footer here */
                height: 60px;
                line-height: 60px; /* Vertically center the text there */
                margin-top: 50px;
            }


            /* Custom page CSS
            -------------------------------------------------- */
            /* Not required for template or sticky footer method. */

            body > .container {
                padding: 60px 15px 0;
            }

            .footer > .container {
                padding-right: 15px;
                padding-left: 15px;
            }

            code {
                font-size: 80%;
            }

        
    #katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}
    
    
    
        
            
        
        Crédit Auto
        
            
                
                    
                        Accueil
                    
                                                                                    
                            
                                Crédit
                            
                            
                                  Créer contrat de crédit auto
                                 Rechercher crédit
                            
                        
                                                            
                        
                            Location
                        
                        
                             Vérifier contrat en cours client                              Emettre conditions de location                         
                    
                                                            
                        
                            Statistiques
                        
                        
                            Rapport de production
                        
                    
                                                            
                        
                            Administration
                        
                        
                            Loueurs partenaires
                            Taux de crédit
                            Conditions de location
                        
                    
                    
                
            
                                                                                    
                 acd
            

            
                Déconnexion
            
            
        
    


                    
        Bienvenue sur l'application Crédit Auto
            
    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                

        

                            Votre menu : 
                Vous êtes connecté en tant que : acd
                Vous êtes : L'Administrateur de Crédit Auto
                Voici la liste de vos fonctionnalités :
                 - Vérifier l'admissibilté d'un client pour établir un contrat de crédit automobile : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Effectuer une simulation : Cliquez ici
                 - Rechercher les contrats en cours : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Consulter le rapport de production : Cliquez ici
                 - Emettre vos conditions de location : Cliquez ici
                 - Définir le taux d'intérêt : Cliquez ici
                 - Consulter la liste des conditions des loueurs partenaires : Cliquez ici
                 - Consulter la liste des loueurs partenaires : Cliquez ici
            

        
    
            

        
    
        
            
                
                    Rechercher un contrat
                    
                        ×
                    
                
                
                    
                        Veuillez remplir au moins un champs pour effectuer la recherche
                    
                    

                    
                    

                    
                    
                        
                            Nom
                            
                        
                        
                            Prénom
                            
                        
                        
                        
                            Ou
                        

                        
                        
                            Numéro de contrat
                            
                        
                    
                
                
                    Fermer
                    Rechercher
                
            
        
    
            
    
        
            
                
                    Vérifier l'admissibilité du client
                    
                        ×
                    
                
                
                    
                        Veuillez saisir au moins un champ de recherche
                    
                    
                    
                    
                        
                            Nom
                            
                        
                        
                            Prénom
                            
                        
                    
                
                
                    Fermer
                    Vérifier
                
            
        
    
        
        
            Copyright © QSI Conseil 2022
        
    

    
    
    

    
    
    
    

    
    

    
        
    
                function checkForm(){
            // if($('input#nameClient').val().length&lt;= 0 &amp;&amp; $('input#firstnameClient').val.length&lt;=0){
            //     $('input#idContrat').prop('disabled',false);
            // }
            if($('input#nameClient').val().length>0 || $('input#firstnameClient').val().length>0){
                $('input#idContrat').prop('disabled',true);
            }else{
                $('input#idContrat').prop('disabled',false);
            }
            if($('input#idContrat').val().length>0){
                $('input#nameClient').prop('disabled',true);
                $('input#firstnameClient').prop('disabled',true);
            }else{
                $('input#nameClient').prop('disabled',false);
                $('input#firstnameClient').prop('disabled',false);
            }
            if(($('input#nameClient').val().length&lt;=0 &amp;&amp; $('input#firstnameClient').val().length&lt;=0) &amp;&amp; $('input#idContrat').val().length&lt;=0){
                $('#errorInput.alert-danger').show();
                $('button#clickSubmit').fadeOut();
                $('div#message').hide();
            }else{
                $('#errorInput.alert-danger').hide();
                $('button#clickSubmit').fadeIn();
            }
        }
                        function checkVerify(){
            if($('input#client').val().length > 0 || $('input#fname').val().length > 0){
                $('#verifyAlert.alert-danger').hide();
                $('button#verifySubmit').fadeIn();
            }else{
                $('#verifyAlert.alert-danger').show();
                $('button#verifySubmit').fadeOut();
                $('div#showClient').hide();
            }
        }
                        $('button#clickSubmit').on('click',function () {
                $.ajax({
                    url: '/credit/search',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        &quot;nameClient&quot;: $('input#nameClient').val(),
                        &quot;fnameClient&quot;: $('input#firstnameClient').val(),
                        &quot;idContract&quot;: $('input#idContrat').val()
                    },
                    async: true,
                    success : function(data){
                        if(data.status === 200){
                            $('div#message').hide();
                            var idContrat = data.id;
                            var url = '/credit/view/contract_id';
                            url = url.replace(&quot;contract_id&quot;, idContrat);
                            window.location.replace(url);
                        }else{
                            if(data.status === 204){
                                $('div#message').contents()
                                    .filter(function() {
                                        return this.nodeType === 3; //Node.TEXT_NODE
                                    }).remove();
                                $('div#message').append(data.message);
                                $('div#message').show();
                            }else{
                                if(data.status === 208){
                                    console.log(data);

                                }else{
                                    $('div#error').contents()
                                        .filter(function() {
                                            return this.nodeType === 3; //Node.TEXT_NODE
                                        }).remove();
                                    $('div#error').append(data.message);
                                    $('div#error').show();
                                }
                            }
                        }
                    },
                    error: function(data){
                        if(data.status === 500){
                            console.log('ERROR !');
                        }
                    }
                });
        });
                        $('button#verifySubmit').on('click',function () {
                $.ajax({
                    url: '/contrat/verification',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        &quot;name&quot;: $('input#client').val(),
                        &quot;fname&quot;: $('input#fname').val()
                    },
                    async: true,
                    success : function(data){
                        if(data.status === 200){
                            var date = new Date(data.date.date);
                            var dateFin = date.getDate()+'-'+date.getMonth()+'-'+date.getFullYear();
                            $('div#showClient').append('Client '+data.firstname+' '+data.lastname+' - Contrat en cours jusqu\'au '+dateFin );
                            $('div#showClient').show();
                        }else{
                            if(data.status === 204){
                                $('div#showClient').contents()
                                    .filter(function() {
                                        return this.nodeType === 3; //Node.TEXT_NODE
                                    }).remove();
                                $('div#showClient').append(data.message);
                                $('div#showClient').show();
                            }
                        }
                    },
                    error: function(data){
                        if(data.status === 500){
                            console.log('ERROR !');
                        }
                    }
                });
        });
            
    

/html[1]</value>
      <webElementGuid>fb0f5267-e4c3-4c7f-b76f-8757f1d176d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]</value>
      <webElementGuid>34fac249-d0c7-45aa-a660-949e6c6c359a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='']/parent::*</value>
      <webElementGuid>2023f46d-2690-4b32-a24c-8636dbd94a70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//html</value>
      <webElementGuid>2175011e-5c93-4b13-a0a7-39c9cf35b681</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//html[(text() = concat(&quot;
        
        Crédit Auto | QSI Conseil
                
        
        
        
        
        
        
        
                
            /* Sticky footer styles
-------------------------------------------------- */
            html {
                position: relative;
                min-height: 100%;
            }
            body {
                /* Margin bottom by footer height */
                margin-bottom: 60px;
            }
            .footer {
                position: absolute;
                bottom: 0;
                width: 100%;
                /* Set the fixed height of the footer here */
                height: 60px;
                line-height: 60px; /* Vertically center the text there */
                margin-top: 50px;
            }


            /* Custom page CSS
            -------------------------------------------------- */
            /* Not required for template or sticky footer method. */

            body > .container {
                padding: 60px 15px 0;
            }

            .footer > .container {
                padding-right: 15px;
                padding-left: 15px;
            }

            code {
                font-size: 80%;
            }

        
    #katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}
    
    
    
        
            
        
        Crédit Auto
        
            
                
                    
                        Accueil
                    
                                                                                    
                            
                                Crédit
                            
                            
                                  Créer contrat de crédit auto
                                 Rechercher crédit
                            
                        
                                                            
                        
                            Location
                        
                        
                             Vérifier contrat en cours client                              Emettre conditions de location                         
                    
                                                            
                        
                            Statistiques
                        
                        
                            Rapport de production
                        
                    
                                                            
                        
                            Administration
                        
                        
                            Loueurs partenaires
                            Taux de crédit
                            Conditions de location
                        
                    
                    
                
            
                                                                                    
                 acd
            

            
                Déconnexion
            
            
        
    


                    
        Bienvenue sur l&quot; , &quot;'&quot; , &quot;application Crédit Auto
            
    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                

        

                            Votre menu : 
                Vous êtes connecté en tant que : acd
                Vous êtes : L&quot; , &quot;'&quot; , &quot;Administrateur de Crédit Auto
                Voici la liste de vos fonctionnalités :
                 - Vérifier l&quot; , &quot;'&quot; , &quot;admissibilté d&quot; , &quot;'&quot; , &quot;un client pour établir un contrat de crédit automobile : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Effectuer une simulation : Cliquez ici
                 - Rechercher les contrats en cours : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Consulter le rapport de production : Cliquez ici
                 - Emettre vos conditions de location : Cliquez ici
                 - Définir le taux d&quot; , &quot;'&quot; , &quot;intérêt : Cliquez ici
                 - Consulter la liste des conditions des loueurs partenaires : Cliquez ici
                 - Consulter la liste des loueurs partenaires : Cliquez ici
            

        
    
            

        
    
        
            
                
                    Rechercher un contrat
                    
                        ×
                    
                
                
                    
                        Veuillez remplir au moins un champs pour effectuer la recherche
                    
                    

                    
                    

                    
                    
                        
                            Nom
                            
                        
                        
                            Prénom
                            
                        
                        
                        
                            Ou
                        

                        
                        
                            Numéro de contrat
                            
                        
                    
                
                
                    Fermer
                    Rechercher
                
            
        
    
            
    
        
            
                
                    Vérifier l&quot; , &quot;'&quot; , &quot;admissibilité du client
                    
                        ×
                    
                
                
                    
                        Veuillez saisir au moins un champ de recherche
                    
                    
                    
                    
                        
                            Nom
                            
                        
                        
                            Prénom
                            
                        
                    
                
                
                    Fermer
                    Vérifier
                
            
        
    
        
        
            Copyright © QSI Conseil 2022
        
    

    
    
    

    
    
    
    

    
    

    
        
    
                function checkForm(){
            // if($(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).val().length&lt;= 0 &amp;&amp; $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).val.length&lt;=0){
            //     $(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,false);
            // }
            if($(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).val().length>0 || $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).val().length>0){
                $(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,true);
            }else{
                $(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,false);
            }
            if($(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).val().length>0){
                $(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,true);
                $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,true);
            }else{
                $(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,false);
                $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,false);
            }
            if(($(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).val().length&lt;=0 &amp;&amp; $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).val().length&lt;=0) &amp;&amp; $(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).val().length&lt;=0){
                $(&quot; , &quot;'&quot; , &quot;#errorInput.alert-danger&quot; , &quot;'&quot; , &quot;).show();
                $(&quot; , &quot;'&quot; , &quot;button#clickSubmit&quot; , &quot;'&quot; , &quot;).fadeOut();
                $(&quot; , &quot;'&quot; , &quot;div#message&quot; , &quot;'&quot; , &quot;).hide();
            }else{
                $(&quot; , &quot;'&quot; , &quot;#errorInput.alert-danger&quot; , &quot;'&quot; , &quot;).hide();
                $(&quot; , &quot;'&quot; , &quot;button#clickSubmit&quot; , &quot;'&quot; , &quot;).fadeIn();
            }
        }
                        function checkVerify(){
            if($(&quot; , &quot;'&quot; , &quot;input#client&quot; , &quot;'&quot; , &quot;).val().length > 0 || $(&quot; , &quot;'&quot; , &quot;input#fname&quot; , &quot;'&quot; , &quot;).val().length > 0){
                $(&quot; , &quot;'&quot; , &quot;#verifyAlert.alert-danger&quot; , &quot;'&quot; , &quot;).hide();
                $(&quot; , &quot;'&quot; , &quot;button#verifySubmit&quot; , &quot;'&quot; , &quot;).fadeIn();
            }else{
                $(&quot; , &quot;'&quot; , &quot;#verifyAlert.alert-danger&quot; , &quot;'&quot; , &quot;).show();
                $(&quot; , &quot;'&quot; , &quot;button#verifySubmit&quot; , &quot;'&quot; , &quot;).fadeOut();
                $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).hide();
            }
        }
                        $(&quot; , &quot;'&quot; , &quot;button#clickSubmit&quot; , &quot;'&quot; , &quot;).on(&quot; , &quot;'&quot; , &quot;click&quot; , &quot;'&quot; , &quot;,function () {
                $.ajax({
                    url: &quot; , &quot;'&quot; , &quot;/credit/search&quot; , &quot;'&quot; , &quot;,
                    type: &quot; , &quot;'&quot; , &quot;POST&quot; , &quot;'&quot; , &quot;,
                    dataType: &quot; , &quot;'&quot; , &quot;json&quot; , &quot;'&quot; , &quot;,
                    data: {
                        &quot;nameClient&quot;: $(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).val(),
                        &quot;fnameClient&quot;: $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).val(),
                        &quot;idContract&quot;: $(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).val()
                    },
                    async: true,
                    success : function(data){
                        if(data.status === 200){
                            $(&quot; , &quot;'&quot; , &quot;div#message&quot; , &quot;'&quot; , &quot;).hide();
                            var idContrat = data.id;
                            var url = &quot; , &quot;'&quot; , &quot;/credit/view/contract_id&quot; , &quot;'&quot; , &quot;;
                            url = url.replace(&quot;contract_id&quot;, idContrat);
                            window.location.replace(url);
                        }else{
                            if(data.status === 204){
                                $(&quot; , &quot;'&quot; , &quot;div#message&quot; , &quot;'&quot; , &quot;).contents()
                                    .filter(function() {
                                        return this.nodeType === 3; //Node.TEXT_NODE
                                    }).remove();
                                $(&quot; , &quot;'&quot; , &quot;div#message&quot; , &quot;'&quot; , &quot;).append(data.message);
                                $(&quot; , &quot;'&quot; , &quot;div#message&quot; , &quot;'&quot; , &quot;).show();
                            }else{
                                if(data.status === 208){
                                    console.log(data);

                                }else{
                                    $(&quot; , &quot;'&quot; , &quot;div#error&quot; , &quot;'&quot; , &quot;).contents()
                                        .filter(function() {
                                            return this.nodeType === 3; //Node.TEXT_NODE
                                        }).remove();
                                    $(&quot; , &quot;'&quot; , &quot;div#error&quot; , &quot;'&quot; , &quot;).append(data.message);
                                    $(&quot; , &quot;'&quot; , &quot;div#error&quot; , &quot;'&quot; , &quot;).show();
                                }
                            }
                        }
                    },
                    error: function(data){
                        if(data.status === 500){
                            console.log(&quot; , &quot;'&quot; , &quot;ERROR !&quot; , &quot;'&quot; , &quot;);
                        }
                    }
                });
        });
                        $(&quot; , &quot;'&quot; , &quot;button#verifySubmit&quot; , &quot;'&quot; , &quot;).on(&quot; , &quot;'&quot; , &quot;click&quot; , &quot;'&quot; , &quot;,function () {
                $.ajax({
                    url: &quot; , &quot;'&quot; , &quot;/contrat/verification&quot; , &quot;'&quot; , &quot;,
                    type: &quot; , &quot;'&quot; , &quot;POST&quot; , &quot;'&quot; , &quot;,
                    dataType: &quot; , &quot;'&quot; , &quot;json&quot; , &quot;'&quot; , &quot;,
                    data: {
                        &quot;name&quot;: $(&quot; , &quot;'&quot; , &quot;input#client&quot; , &quot;'&quot; , &quot;).val(),
                        &quot;fname&quot;: $(&quot; , &quot;'&quot; , &quot;input#fname&quot; , &quot;'&quot; , &quot;).val()
                    },
                    async: true,
                    success : function(data){
                        if(data.status === 200){
                            var date = new Date(data.date.date);
                            var dateFin = date.getDate()+&quot; , &quot;'&quot; , &quot;-&quot; , &quot;'&quot; , &quot;+date.getMonth()+&quot; , &quot;'&quot; , &quot;-&quot; , &quot;'&quot; , &quot;+date.getFullYear();
                            $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).append(&quot; , &quot;'&quot; , &quot;Client &quot; , &quot;'&quot; , &quot;+data.firstname+&quot; , &quot;'&quot; , &quot; &quot; , &quot;'&quot; , &quot;+data.lastname+&quot; , &quot;'&quot; , &quot; - Contrat en cours jusqu\&quot; , &quot;'&quot; , &quot;au &quot; , &quot;'&quot; , &quot;+dateFin );
                            $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).show();
                        }else{
                            if(data.status === 204){
                                $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).contents()
                                    .filter(function() {
                                        return this.nodeType === 3; //Node.TEXT_NODE
                                    }).remove();
                                $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).append(data.message);
                                $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).show();
                            }
                        }
                    },
                    error: function(data){
                        if(data.status === 500){
                            console.log(&quot; , &quot;'&quot; , &quot;ERROR !&quot; , &quot;'&quot; , &quot;);
                        }
                    }
                });
        });
            
    

/html[1]&quot;) or . = concat(&quot;
        
        Crédit Auto | QSI Conseil
                
        
        
        
        
        
        
        
                
            /* Sticky footer styles
-------------------------------------------------- */
            html {
                position: relative;
                min-height: 100%;
            }
            body {
                /* Margin bottom by footer height */
                margin-bottom: 60px;
            }
            .footer {
                position: absolute;
                bottom: 0;
                width: 100%;
                /* Set the fixed height of the footer here */
                height: 60px;
                line-height: 60px; /* Vertically center the text there */
                margin-top: 50px;
            }


            /* Custom page CSS
            -------------------------------------------------- */
            /* Not required for template or sticky footer method. */

            body > .container {
                padding: 60px 15px 0;
            }

            .footer > .container {
                padding-right: 15px;
                padding-left: 15px;
            }

            code {
                font-size: 80%;
            }

        
    #katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}
    
    
    
        
            
        
        Crédit Auto
        
            
                
                    
                        Accueil
                    
                                                                                    
                            
                                Crédit
                            
                            
                                  Créer contrat de crédit auto
                                 Rechercher crédit
                            
                        
                                                            
                        
                            Location
                        
                        
                             Vérifier contrat en cours client                              Emettre conditions de location                         
                    
                                                            
                        
                            Statistiques
                        
                        
                            Rapport de production
                        
                    
                                                            
                        
                            Administration
                        
                        
                            Loueurs partenaires
                            Taux de crédit
                            Conditions de location
                        
                    
                    
                
            
                                                                                    
                 acd
            

            
                Déconnexion
            
            
        
    


                    
        Bienvenue sur l&quot; , &quot;'&quot; , &quot;application Crédit Auto
            
    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                

        

                            Votre menu : 
                Vous êtes connecté en tant que : acd
                Vous êtes : L&quot; , &quot;'&quot; , &quot;Administrateur de Crédit Auto
                Voici la liste de vos fonctionnalités :
                 - Vérifier l&quot; , &quot;'&quot; , &quot;admissibilté d&quot; , &quot;'&quot; , &quot;un client pour établir un contrat de crédit automobile : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Effectuer une simulation : Cliquez ici
                 - Rechercher les contrats en cours : Cliquez ici
                 - Consulter la liste des crédits automobiles : Cliquez ici
                 - Consulter le rapport de production : Cliquez ici
                 - Emettre vos conditions de location : Cliquez ici
                 - Définir le taux d&quot; , &quot;'&quot; , &quot;intérêt : Cliquez ici
                 - Consulter la liste des conditions des loueurs partenaires : Cliquez ici
                 - Consulter la liste des loueurs partenaires : Cliquez ici
            

        
    
            

        
    
        
            
                
                    Rechercher un contrat
                    
                        ×
                    
                
                
                    
                        Veuillez remplir au moins un champs pour effectuer la recherche
                    
                    

                    
                    

                    
                    
                        
                            Nom
                            
                        
                        
                            Prénom
                            
                        
                        
                        
                            Ou
                        

                        
                        
                            Numéro de contrat
                            
                        
                    
                
                
                    Fermer
                    Rechercher
                
            
        
    
            
    
        
            
                
                    Vérifier l&quot; , &quot;'&quot; , &quot;admissibilité du client
                    
                        ×
                    
                
                
                    
                        Veuillez saisir au moins un champ de recherche
                    
                    
                    
                    
                        
                            Nom
                            
                        
                        
                            Prénom
                            
                        
                    
                
                
                    Fermer
                    Vérifier
                
            
        
    
        
        
            Copyright © QSI Conseil 2022
        
    

    
    
    

    
    
    
    

    
    

    
        
    
                function checkForm(){
            // if($(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).val().length&lt;= 0 &amp;&amp; $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).val.length&lt;=0){
            //     $(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,false);
            // }
            if($(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).val().length>0 || $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).val().length>0){
                $(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,true);
            }else{
                $(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,false);
            }
            if($(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).val().length>0){
                $(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,true);
                $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,true);
            }else{
                $(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,false);
                $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).prop(&quot; , &quot;'&quot; , &quot;disabled&quot; , &quot;'&quot; , &quot;,false);
            }
            if(($(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).val().length&lt;=0 &amp;&amp; $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).val().length&lt;=0) &amp;&amp; $(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).val().length&lt;=0){
                $(&quot; , &quot;'&quot; , &quot;#errorInput.alert-danger&quot; , &quot;'&quot; , &quot;).show();
                $(&quot; , &quot;'&quot; , &quot;button#clickSubmit&quot; , &quot;'&quot; , &quot;).fadeOut();
                $(&quot; , &quot;'&quot; , &quot;div#message&quot; , &quot;'&quot; , &quot;).hide();
            }else{
                $(&quot; , &quot;'&quot; , &quot;#errorInput.alert-danger&quot; , &quot;'&quot; , &quot;).hide();
                $(&quot; , &quot;'&quot; , &quot;button#clickSubmit&quot; , &quot;'&quot; , &quot;).fadeIn();
            }
        }
                        function checkVerify(){
            if($(&quot; , &quot;'&quot; , &quot;input#client&quot; , &quot;'&quot; , &quot;).val().length > 0 || $(&quot; , &quot;'&quot; , &quot;input#fname&quot; , &quot;'&quot; , &quot;).val().length > 0){
                $(&quot; , &quot;'&quot; , &quot;#verifyAlert.alert-danger&quot; , &quot;'&quot; , &quot;).hide();
                $(&quot; , &quot;'&quot; , &quot;button#verifySubmit&quot; , &quot;'&quot; , &quot;).fadeIn();
            }else{
                $(&quot; , &quot;'&quot; , &quot;#verifyAlert.alert-danger&quot; , &quot;'&quot; , &quot;).show();
                $(&quot; , &quot;'&quot; , &quot;button#verifySubmit&quot; , &quot;'&quot; , &quot;).fadeOut();
                $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).hide();
            }
        }
                        $(&quot; , &quot;'&quot; , &quot;button#clickSubmit&quot; , &quot;'&quot; , &quot;).on(&quot; , &quot;'&quot; , &quot;click&quot; , &quot;'&quot; , &quot;,function () {
                $.ajax({
                    url: &quot; , &quot;'&quot; , &quot;/credit/search&quot; , &quot;'&quot; , &quot;,
                    type: &quot; , &quot;'&quot; , &quot;POST&quot; , &quot;'&quot; , &quot;,
                    dataType: &quot; , &quot;'&quot; , &quot;json&quot; , &quot;'&quot; , &quot;,
                    data: {
                        &quot;nameClient&quot;: $(&quot; , &quot;'&quot; , &quot;input#nameClient&quot; , &quot;'&quot; , &quot;).val(),
                        &quot;fnameClient&quot;: $(&quot; , &quot;'&quot; , &quot;input#firstnameClient&quot; , &quot;'&quot; , &quot;).val(),
                        &quot;idContract&quot;: $(&quot; , &quot;'&quot; , &quot;input#idContrat&quot; , &quot;'&quot; , &quot;).val()
                    },
                    async: true,
                    success : function(data){
                        if(data.status === 200){
                            $(&quot; , &quot;'&quot; , &quot;div#message&quot; , &quot;'&quot; , &quot;).hide();
                            var idContrat = data.id;
                            var url = &quot; , &quot;'&quot; , &quot;/credit/view/contract_id&quot; , &quot;'&quot; , &quot;;
                            url = url.replace(&quot;contract_id&quot;, idContrat);
                            window.location.replace(url);
                        }else{
                            if(data.status === 204){
                                $(&quot; , &quot;'&quot; , &quot;div#message&quot; , &quot;'&quot; , &quot;).contents()
                                    .filter(function() {
                                        return this.nodeType === 3; //Node.TEXT_NODE
                                    }).remove();
                                $(&quot; , &quot;'&quot; , &quot;div#message&quot; , &quot;'&quot; , &quot;).append(data.message);
                                $(&quot; , &quot;'&quot; , &quot;div#message&quot; , &quot;'&quot; , &quot;).show();
                            }else{
                                if(data.status === 208){
                                    console.log(data);

                                }else{
                                    $(&quot; , &quot;'&quot; , &quot;div#error&quot; , &quot;'&quot; , &quot;).contents()
                                        .filter(function() {
                                            return this.nodeType === 3; //Node.TEXT_NODE
                                        }).remove();
                                    $(&quot; , &quot;'&quot; , &quot;div#error&quot; , &quot;'&quot; , &quot;).append(data.message);
                                    $(&quot; , &quot;'&quot; , &quot;div#error&quot; , &quot;'&quot; , &quot;).show();
                                }
                            }
                        }
                    },
                    error: function(data){
                        if(data.status === 500){
                            console.log(&quot; , &quot;'&quot; , &quot;ERROR !&quot; , &quot;'&quot; , &quot;);
                        }
                    }
                });
        });
                        $(&quot; , &quot;'&quot; , &quot;button#verifySubmit&quot; , &quot;'&quot; , &quot;).on(&quot; , &quot;'&quot; , &quot;click&quot; , &quot;'&quot; , &quot;,function () {
                $.ajax({
                    url: &quot; , &quot;'&quot; , &quot;/contrat/verification&quot; , &quot;'&quot; , &quot;,
                    type: &quot; , &quot;'&quot; , &quot;POST&quot; , &quot;'&quot; , &quot;,
                    dataType: &quot; , &quot;'&quot; , &quot;json&quot; , &quot;'&quot; , &quot;,
                    data: {
                        &quot;name&quot;: $(&quot; , &quot;'&quot; , &quot;input#client&quot; , &quot;'&quot; , &quot;).val(),
                        &quot;fname&quot;: $(&quot; , &quot;'&quot; , &quot;input#fname&quot; , &quot;'&quot; , &quot;).val()
                    },
                    async: true,
                    success : function(data){
                        if(data.status === 200){
                            var date = new Date(data.date.date);
                            var dateFin = date.getDate()+&quot; , &quot;'&quot; , &quot;-&quot; , &quot;'&quot; , &quot;+date.getMonth()+&quot; , &quot;'&quot; , &quot;-&quot; , &quot;'&quot; , &quot;+date.getFullYear();
                            $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).append(&quot; , &quot;'&quot; , &quot;Client &quot; , &quot;'&quot; , &quot;+data.firstname+&quot; , &quot;'&quot; , &quot; &quot; , &quot;'&quot; , &quot;+data.lastname+&quot; , &quot;'&quot; , &quot; - Contrat en cours jusqu\&quot; , &quot;'&quot; , &quot;au &quot; , &quot;'&quot; , &quot;+dateFin );
                            $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).show();
                        }else{
                            if(data.status === 204){
                                $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).contents()
                                    .filter(function() {
                                        return this.nodeType === 3; //Node.TEXT_NODE
                                    }).remove();
                                $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).append(data.message);
                                $(&quot; , &quot;'&quot; , &quot;div#showClient&quot; , &quot;'&quot; , &quot;).show();
                            }
                        }
                    },
                    error: function(data){
                        if(data.status === 500){
                            console.log(&quot; , &quot;'&quot; , &quot;ERROR !&quot; , &quot;'&quot; , &quot;);
                        }
                    }
                });
        });
            
    

/html[1]&quot;))]</value>
      <webElementGuid>8655fd6a-cdc1-4a41-afd0-1b797f53fbbb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
