<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>nav_Crdit Auto                                                                                Accueil</name>
   <tag></tag>
   <elementGuidId>6ded3c1e-b235-4335-87a2-69d77572f76b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='mainNav']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#mainNav</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>nav</value>
      <webElementGuid>fc7e56ab-f10c-4189-a6d1-831f620c701c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>navbar navbar-toggleable-md navbar-expand-lg navbar-dark bg-dark</value>
      <webElementGuid>aeb10f79-8f94-41de-845d-65691aa84c56</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>mainNav</value>
      <webElementGuid>62745448-e808-42cb-b498-28b07a824019</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
        
        Crédit Auto
        
            
                
                    
                        Accueil
                    
                    
        
    </value>
      <webElementGuid>161d4045-300e-4c9b-86f4-08d8404f92ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainNav&quot;)</value>
      <webElementGuid>bf663f87-b42c-4b26-a69a-494e573f68aa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//nav[@id='mainNav']</value>
      <webElementGuid>d04efa81-2a4a-48f6-baa7-eaa2fdeae004</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='page-top']/nav</value>
      <webElementGuid>7e5179ba-81ca-4750-b0c8-5f519ee7bebe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//nav</value>
      <webElementGuid>8fabcb6d-2197-47bc-b025-56e1ea67993a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//nav[@id = 'mainNav' and (text() = '
        
            
        
        Crédit Auto
        
            
                
                    
                        Accueil
                    
                    
        
    ' or . = '
        
            
        
        Crédit Auto
        
            
                
                    
                        Accueil
                    
                    
        
    ')]</value>
      <webElementGuid>4b8836c1-8f1f-4c89-a24e-54f3d9e292d3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
