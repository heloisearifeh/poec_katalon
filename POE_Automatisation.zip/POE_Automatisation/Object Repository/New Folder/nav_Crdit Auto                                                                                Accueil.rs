<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>nav_Crdit Auto                                                                                Accueil</name>
   <tag></tag>
   <elementGuidId>93b130bb-800a-42e2-9f13-5d4b46082ff8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='mainNav']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#mainNav</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>nav</value>
      <webElementGuid>f31cdad5-d2c2-4d32-aba4-f640880bcda3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>navbar navbar-toggleable-md navbar-expand-lg navbar-dark bg-dark</value>
      <webElementGuid>010c2749-e7e9-4c95-94d6-78058ad2bf96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>mainNav</value>
      <webElementGuid>e6d05695-519d-4e9a-8c49-b25b2d635ba2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
        
        Crédit Auto
        
            
                
                    
                        Accueil
                    
                    
        
    </value>
      <webElementGuid>bfd94709-37e8-4bf5-bd44-28a7d651f13d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainNav&quot;)</value>
      <webElementGuid>bba90601-0cc1-490d-82a2-b0958172389d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//nav[@id='mainNav']</value>
      <webElementGuid>762ad4cf-7e27-4ca6-a09d-757bb7413f07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='page-top']/nav</value>
      <webElementGuid>a3895e67-e2f8-498a-a067-c2f5bd456d8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//nav</value>
      <webElementGuid>1cb51975-7490-4066-bc68-3f18b3e3865b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//nav[@id = 'mainNav' and (text() = '
        
            
        
        Crédit Auto
        
            
                
                    
                        Accueil
                    
                    
        
    ' or . = '
        
            
        
        Crédit Auto
        
            
                
                    
                        Accueil
                    
                    
        
    ')]</value>
      <webElementGuid>c5c6097d-c60e-48d8-988b-c72765f3797d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
