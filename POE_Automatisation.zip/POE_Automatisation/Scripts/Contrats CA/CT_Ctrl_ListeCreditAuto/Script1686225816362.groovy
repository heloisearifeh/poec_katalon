import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory

WebUI.openBrowser('')

WebUI.callTestCase(findTestCase('Libraries/F_Login_CA'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/Page liste contrats/a_Cliquez ici_1'))

WebUI.verifyElementPresent(findTestObject('Object Repository/Page liste contrats/table_Id                            Client _67f442'), 
    0)

//  mettre le nombre de lignes de la liste a 8
WebUI.selectOptionByValue(findTestObject('Object Repository/Page liste contrats/select_Voir tout                           _86e664'), 
    '8', true)

WebUI.getText(findTestObject('Object Repository/Page liste contrats/table_Id                            Client _67f442'), 
    FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/Page liste contrats/td_11111111155'))

WebUI.verifyElementText(findTestObject('Object Repository/Page liste contrats/td_11111111155'), '11111111155')

WebDriver driver = DriverFactory.getWebDriver()

'Expected value from Table'
String ExpectedId = '11111111155'

String ExpectedCredit = '20000'

//'To locate table'
//WebElement Table = driver.findElement(By.xpath("//table/tbody"))
WebElement Table = driver.findElement(By.xpath('//*[@id="table-contrats"]'))

//'To locate rows of table it will Capture all the rows available in the table'
List<WebElement> rows_table = Table.findElements(By.tagName('tr'))

List<WebElement> Columns_row = rows_table.get(5).findElements(By.tagName('td'))

println('Id:' + Columns_row.get(0).getText())

println('Crédit: ' + Columns_row.get(3).getText())

String tableId = Columns_row.get(0).getText()

String tableCredit = Columns_row.get(3).getText()

println('tableId.compareTo(ExpectedId) : ' + tableId.compareTo(ExpectedId))

println('tableCredit.compareTo(ExpectedCredit) : ' + tableCredit.compareTo(ExpectedCredit))

if ((tableId.trim().compareTo(ExpectedId) != 0) || (tableCredit.trim().compareTo(ExpectedCredit) != 0)) {
    println('ERREUR')
}

// version avec la boucle
'Loop will execute for all the rows of the table'
Loop: for (int col = 0; col < Columns_row.size(); col++) {
    tableId = Columns_row.get(0).getText()

    if (col == 3) {
        tableCredit = Columns_row.get(col).getText()

        println('tableCredit trouvé : ' + tableCredit)

        break
    }
    
    println((tableId + ' ') + tableCredit)
}

WebUI.closeBrowser()

