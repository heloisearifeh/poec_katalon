import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import com.thoughtworks.selenium.webdriven.commands.IsTextPresent as IsTextPresent
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.exception.StepFailedException as StepFailedException

WebUI.openBrowser('')
WebUI.navigateToUrl('http://credit-auto.qsiconseil.ma/')

WebUI.click(findTestObject('Object Repository/Page_Crdit Auto  QSI Conseil/a_Accs Crdit Auto'))



'Récupération des données du fichier Excel'
TestData td = findTestData('Data Files/Auth Login Test Data XLS')

'Nombre total de lignes de la liste de données'
int totalRow = td.getRowNumbers()

println('nb total de lignes : ' + totalRow)



'Pour chaque ligne, affecter user et password '
for (int i = 1; i <= totalRow; i++) {
    // User (variable du cas de test)
    user = td.getValue(1, i)

    // Password (variable du cas de test)
    password = td.getValue(2, i)

    println((('Connexion avec ' + user) + ' / ') + password)


    WebUI.setText(findTestObject('Object Repository/Page_Crdit Auto  QSI Conseil/input_concat(Nom d, , utilisateur)__username'), 
        user)

    WebUI.setText(findTestObject('Object Repository/Page_Crdit Auto  QSI Conseil/input_Mot de passe__password'), password)

    WebUI.click(findTestObject('Object Repository/Page_Crdit Auto  QSI Conseil/button_Se connecter'))

    //boolean isTextPresent = WebUI.verifyTextPresent('Bienvenue sur l\'application Crédit Auto', false, FailureHandling.OPTIONAL)

    if (WebUI.verifyTextPresent('Bienvenue sur l\'application Crédit Auto', false, FailureHandling.OPTIONAL)) {
        println('Success!!!')

        WebUI.click(findTestObject('Object Repository/Page_Crdit Auto  QSI Conseil/a_Dconnexion'))
		WebUI.click(findTestObject('Object Repository/Page_Crdit Auto  QSI Conseil/a_Accs Crdit Auto'))
		
    } else if (WebUI.verifyTextPresent('Identifiants invalides.', false, FailureHandling.OPTIONAL)){
        println('Login KO!!!')
    } else
    {
		println('Other Error!!!')
	}
}

WebUI.closeBrowser()

